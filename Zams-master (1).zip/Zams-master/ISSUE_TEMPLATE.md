## Checklist
- [ ] I am on the latest version

- [ ] I am on the latest version of dependencies

- [ ] I am on the latest version of Discord

- [ ] I have followed the instructions in the [Wiki](https://github.com/justdotJS/SimplePresence/wiki)

## Type
Please select what type of issue this is. Please do not use Issues for Support, [ask on the Discord](https://discord.gg/MpnbrX7)!

[ ] Feature Request

[ ] Bug Report

## Description
Replace this text with a description of the bug or feature request. If this is a bug report, include what you expected to happen and what actually happened.

## Specifications
Version is the version of EasyRPC, Platform is Windows/macOS/Linux, and Platform Version is the version of the platform (e.g. 10.13.1 for macOS, or 10 for Windows.).
  - [ ] Version: 
  - [ ] Platform: 
  - [ ] Platform Version: 
